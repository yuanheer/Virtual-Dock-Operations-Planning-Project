#!/usr/bin/env python3
"""Run the experiment suite used in the write-up.

The script covers:
  * exact solutions (DP + MILP) and a preemptive lower bound for both instances
  * dispatch rules, GA and SA on the two instances
  * a small heterogeneous-processing benchmark
  * one-factor sensitivity analysis
  * the zero-wait certificate under scaled travel times
  * the sum-of-completion vs makespan comparison

Everything is written to ``results/`` as CSV/JSON so the figures and the report
can be regenerated without re-running the optimisation.
"""

from __future__ import annotations

import argparse
import csv
import json
import random
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agvsched.exact import dp_min_cmax, solve_dp, solve_milp, srpt_lower_bound
from agvsched.heuristics import (dispatch_rules, genetic_algorithm,
                                 random_search, simulated_annealing)
from agvsched.instance import Instance, Task, load_instance
from agvsched.model import jit_certificate, metrics

SCENARIOS = ("load_only", "mixed")
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)


def write_csv(path: Path, rows: list[dict], columns: list[str] | None = None) -> None:
    if not rows:
        return
    columns = columns or list(rows[0].keys())
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=columns)
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in columns})


def exact_solution(inst: Instance, time_limit: float = 60.0) -> dict:
    """Use DP when it is certified, otherwise fall back to the MILP."""
    if inst.n <= 14 and inst.n_cranes == 2:
        result = solve_dp(inst)
        if result["status"] == "PROVEN_OPTIMAL":
            return result
    return solve_milp(inst, time_limit=time_limit)


def expand_cranes(inst: Instance, n_cranes: int) -> Instance:
    """Duplicate travel data when a sensitivity scenario adds cranes.

    This is a synthetic what-if: new cranes inherit the timetable of an
    existing crane.  It is only used to study the trend, not to predict a real
    terminal expansion.
    """
    if n_cranes <= inst.n_cranes:
        return inst.with_options(n_cranes=n_cranes)
    base = inst.n_cranes
    load = dict(inst.travel_load)
    unload = dict(inst.travel_unload)
    for k in range(base + 1, n_cranes + 1):
        src = (k - 1) % base + 1
        for spot in range(1, inst.n_spots + 1):
            load[(spot, k)] = load[(spot, src)]
            unload[(k, spot)] = unload[(src, spot)]
    return Instance(
        scenario=inst.scenario, tasks=inst.tasks,
        travel_load=load, travel_unload=unload,
        alpha=inst.alpha, beta=inst.beta,
        road_capacity=inst.road_capacity, n_spots=inst.n_spots,
        n_cranes=n_cranes,
    )


def experiment_exact() -> None:
    print("[1/6] exact solutions")
    rows = []
    for scenario in SCENARIOS:
        inst = load_instance(ROOT / "data", scenario)
        cert = jit_certificate(inst)
        dp = solve_dp(inst)
        milp_result = solve_milp(inst, time_limit=120)
        bound = srpt_lower_bound(inst)
        rows.append({
            "scenario": scenario, "tasks": inst.n, "cranes": inst.n_cranes,
            "road_capacity": inst.road_capacity,
            "zero_wait_ok": cert["satisfied"],
            "capacity_condition": cert["capacity_condition"],
            "dp_objective": dp["objective"], "dp_status": dp["status"],
            "dp_time_s": round(dp["elapsed"], 3), "dp_states": dp.get("states"),
            "milp_objective": milp_result["objective"],
            "milp_status": milp_result["status"],
            "milp_time_s": round(milp_result["elapsed"], 3),
            "milp_vars": milp_result["n_vars"], "milp_cons": milp_result["n_cons"],
            "srpt_lower_bound": bound["lb"],
            "makespan": dp["metrics"]["makespan"],
            "peak_corridor": dp["metrics"]["peak_corridor"],
            "max_wait": dp["metrics"]["max_wait"],
        })
        print(f"  {scenario}: DP={dp['objective']:.0f} ({dp['status']}), "
              f"MILP={milp_result['objective']:.0f} ({milp_result['status']}), "
              f"LB={bound['lb']:.0f}")
    write_csv(RESULTS / "exact_summary.csv", rows)


def experiment_heuristics() -> None:
    print("[2/6] heuristics on the two base instances")
    summary = []
    details = []
    for scenario in SCENARIOS:
        inst = load_instance(ROOT / "data", scenario)
        optimal = exact_solution(inst)["objective"]
        methods = dispatch_rules(inst) + [
            random_search(inst, runs=300, seed=1),
            genetic_algorithm(inst, pop_size=40, generations=80, seed=1),
            simulated_annealing(inst, restarts=2, iters_per_temp=80, seed=1),
        ]
        for result in methods:
            gap = (result["objective"] - optimal) / optimal * 100
            summary.append({
                "scenario": scenario, "method": result["method"],
                "objective": result["objective"],
                "makespan": result["metrics"]["makespan"],
                "gap_pct": round(gap, 3),
                "time_s": round(result["elapsed"], 3),
                "evaluations": result["evaluations"],
            })
            details.append({"scenario": scenario, "method": result["method"],
                            "order": " ".join(map(str, result["order"])),
                            "assign": " ".join(map(str, result["assign"] or []))})
        print(f"  {scenario}: {len(methods)} methods, best gap "
              f"{min(r['gap_pct'] for r in summary if r['scenario'] == scenario):.2f}%")
    write_csv(RESULTS / "heuristics_summary.csv", summary)
    write_csv(RESULTS / "heuristics_details.csv", details)


def experiment_heterogeneous() -> None:
    print("[3/6] heterogeneous-processing benchmark")
    rng = random.Random(7)
    summary = []
    detail = []
    for scenario in SCENARIOS:
        base = load_instance(ROOT / "data", scenario)
        for case in range(4):
            tasks = tuple(
                Task(t.task_id, max(0, t.ready + rng.randint(-2, 2)),
                     t.kind, rng.randint(10, 30))
                for t in base.tasks
            )
            inst = Instance(
                scenario=f"{scenario}_p{case}", tasks=tasks,
                travel_load=base.travel_load, travel_unload=base.travel_unload,
                alpha=base.alpha, beta=base.beta,
                road_capacity=base.road_capacity, n_spots=base.n_spots,
                n_cranes=base.n_cranes,
            )
            ref = exact_solution(inst, time_limit=60)
            if ref["objective"] is None:
                continue
            methods = dispatch_rules(inst) + [
                genetic_algorithm(inst, pop_size=35, generations=60, seed=case),
                simulated_annealing(inst, restarts=2, iters_per_temp=60, seed=case),
            ]
            for result in methods:
                gap = (result["objective"] - ref["objective"]) / ref["objective"] * 100
                detail.append({
                    "scenario": scenario, "case": case, "method": result["method"],
                    "objective": result["objective"], "reference": ref["objective"],
                    "gap_pct": round(gap, 3), "time_s": round(result["elapsed"], 3),
                })
            print(f"  {scenario} case {case}: ref={ref['objective']:.0f}")
    # aggregate by method
    methods = sorted({row["method"] for row in detail})
    for method in methods:
        subset = [row for row in detail if row["method"] == method]
        summary.append({
            "method": method, "runs": len(subset),
            "mean_gap_pct": round(sum(r["gap_pct"] for r in subset) / len(subset), 3),
            "max_gap_pct": round(max(r["gap_pct"] for r in subset), 3),
            "hit_rate_pct": round(100 * sum(1 for r in subset if r["gap_pct"] < 1e-6) / len(subset), 1),
            "mean_time_s": round(sum(r["time_s"] for r in subset) / len(subset), 3),
        })
    write_csv(RESULTS / "benchmark_heterogeneous_detail.csv", detail)
    write_csv(RESULTS / "benchmark_heterogeneous_summary.csv", summary)
    print(f"  {len(detail)} runs, {len(summary)} methods")


def experiment_sensitivity() -> None:
    print("[4/6] sensitivity analysis")
    rows = []
    factors = {
        "cranes": [1, 2, 3, 4],
        "road_capacity": [1, 2, 4],
        "travel_scale": [0.8, 1.0, 1.2],
        "processing_scale": [0.8, 1.0, 1.25],
        "ready_shift": [0, 5, 10],
        "spots": [1, 2, 4],
    }
    for scenario in SCENARIOS:
        base = load_instance(ROOT / "data", scenario)
        base_value = exact_solution(base)["objective"]
        for factor, values in factors.items():
            for value in values:
                if factor == "cranes":
                    inst = expand_cranes(base, value)
                elif factor == "road_capacity":
                    inst = base.with_options(road_capacity=value)
                elif factor == "travel_scale":
                    inst = base.with_options(travel_scale=value)
                elif factor == "processing_scale":
                    inst = base.with_options(p_scale=value)
                elif factor == "ready_shift":
                    inst = base.with_options(ready_shift=value)
                else:
                    inst = base.with_options(n_spots=value)
                cert = jit_certificate(inst, base_delta=jit_certificate(base)["travel_spread"])
                # Tight road capacity makes the time-indexed model harder.
                time_limit = 120 if (factor == "road_capacity" and value < base.road_capacity) else 15
                result = exact_solution(inst, time_limit=time_limit)
                value_obj = result.get("objective")
                rows.append({
                    "scenario": scenario, "factor": factor, "value": value,
                    "objective": value_obj,
                    "change_pct": (round((value_obj - base_value) / base_value * 100, 3)
                                   if value_obj is not None else None),
                    "status": result.get("status"),
                    "zero_wait_ok": cert["satisfied"],
                    "capacity_condition": cert["capacity_condition"],
                })
                print(f"  {scenario:9s} {factor:16s}={value}: {value_obj} "
                      f"({cert['capacity_condition']})")
    write_csv(RESULTS / "sensitivity.csv", rows)


def experiment_jit() -> None:
    print("[5/6] zero-wait certificate")
    rows = []
    for scenario in SCENARIOS:
        base = load_instance(ROOT / "data", scenario)
        base_delta = jit_certificate(base)["travel_spread"]
        for gamma in (0.7, 0.8, 0.9, 1.0, 1.05, 1.1, 1.15, 7 / 6, 1.2, 1.3):
            inst = base.with_options(travel_scale=gamma)
            cert = jit_certificate(inst, base_delta=base_delta)
            margin = min(row["margin"] for row in cert["rows"])
            rows.append({
                "scenario": scenario, "travel_scale": round(gamma, 4),
                "actual_spread": cert["travel_spread"],
                "margin": margin,
                "capacity_condition": cert["capacity_condition"],
                "satisfied": cert["satisfied"],
                "gamma_star": cert["gamma_star"],
            })
            print(f"  {scenario:9s} gamma={gamma:.4f}: spread={cert['travel_spread']} "
                  f"margin={margin} satisfied={cert['satisfied']}")
    write_csv(RESULTS / "jit_check.csv", rows)


def experiment_dual_objective() -> None:
    print("[6/6] sum-of-completion vs makespan")
    rows = []
    for scenario in SCENARIOS:
        inst = load_instance(ROOT / "data", scenario)
        sum_result = exact_solution(inst)
        # Lexicographic step: find Cmax*, then minimise sum C subject to it.
        if inst.n <= 14 and inst.n_cranes == 2:
            cmax_star = dp_min_cmax(inst)
            constrained = solve_dp(inst, cmax_cap=cmax_star)
        else:
            makespan_result = solve_milp(inst, objective="makespan", time_limit=120)
            cmax_star = makespan_result["objective"]
            constrained = solve_milp(inst, objective="sum_completion", time_limit=20,
                                     horizon=int(cmax_star))
        rows.append({
            "scenario": scenario,
            "sumC_opt_sumC": sum_result["metrics"]["sum_completion"],
            "sumC_opt_plan_makespan": sum_result["metrics"]["makespan"],
            "cmax_star": cmax_star,
            "best_sumC_under_Cmax": constrained["objective"],
            "constrained_status": constrained["status"],
        })
        print(f"  {scenario}: min sumC={sum_result['metrics']['sum_completion']} "
              f"(returned plan Cmax={sum_result['metrics']['makespan']}); "
              f"min Cmax={cmax_star}; "
              f"best sumC with Cmax<=Cmax* = {constrained['objective']}")
    write_csv(RESULTS / "dual_objective.csv", rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--skip-slow", action="store_true",
                        help="skip the sensitivity and heterogeneous benchmarks")
    parser.add_argument("--only", choices=["all", "exact", "heuristics", "heterogeneous",
                                          "sensitivity", "jit", "dual"], default="all",
                        help="run only one experiment group")
    args = parser.parse_args()

    t0 = time.perf_counter()
    if args.only in ("all", "exact"):
        experiment_exact()
    if args.only in ("all", "heuristics"):
        experiment_heuristics()
    if args.only == "all" and not args.skip_slow:
        experiment_heterogeneous()
        experiment_sensitivity()
    if args.only == "heterogeneous":
        experiment_heterogeneous()
    if args.only == "sensitivity":
        experiment_sensitivity()
    if args.only in ("all", "jit"):
        experiment_jit()
    if args.only in ("all", "dual"):
        experiment_dual_objective()

    summary = {
        "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "elapsed_s": round(time.perf_counter() - t0, 1),
        "scenarios": list(SCENARIOS),
        "outputs": sorted(p.name for p in RESULTS.glob("*.*")),
    }
    (RESULTS / "summary.json").write_text(json.dumps(summary, indent=2, ensure_ascii=False),
                                          encoding="utf-8")
    print(f"\ndone in {summary['elapsed_s']}s; results in results/")


if __name__ == "__main__":
    main()
