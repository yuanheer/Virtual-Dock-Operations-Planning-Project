#!/usr/bin/env python3
"""Independent audit of a route table.

The audit deliberately does not import the solver or the decoder.  It reads the
original data files and the route CSV, rebuilds every event, and recomputes the
objective.  If this script says PASS, the timetable is consistent with the data
regardless of how it was produced.

Usage:
    python scripts/audit.py --scenario load_only --routes results/routes_load_only_dp.csv
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def read_csv(path: Path):
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def as_int(value, label, errors):
    text = str(value).strip()
    try:
        number = float(text)
    except ValueError:
        errors.append(f"{label}: not a number ({value!r})")
        return None
    if not number.is_integer():
        errors.append(f"{label}: not an integer ({value!r})")
        return None
    return int(number)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--scenario", choices=["load_only", "mixed"], required=True)
    parser.add_argument("--routes", type=Path, required=True)
    args = parser.parse_args()

    task_file = {"load_only": "tasks_load_only.csv", "mixed": "tasks_mixed.csv"}[args.scenario]
    tasks = {}
    for row in read_csv(ROOT / "data" / task_file):
        tasks[int(row["task_id"])] = {
            "ready": int(row["ready_time"]),
            "kind": "L" if row["job_type"] == "load" else "U",
            "p": int(row["processing_time"]),
        }
    travel_load = {(int(r["spot"]), int(r["crane"])): int(r["travel_time"])
                   for r in read_csv(ROOT / "data" / "travel_loading.csv")}
    travel_unload = {(int(r["crane"]), int(r["spot"])): int(r["travel_time"])
                     for r in read_csv(ROOT / "data" / "travel_unloading.csv")}
    fixed = {r["job_type"]: int(r["travel_time"])
             for r in read_csv(ROOT / "data" / "fixed_travel.csv")}
    resources = {r["parameter"]: int(r["value"])
                 for r in read_csv(ROOT / "data" / "resources.csv")}
    alpha, beta = fixed["load"], fixed["unload"]
    capacity = resources["road_capacity"]

    rows = read_csv(args.routes)
    errors = []
    if len(rows) != len(tasks):
        errors.append(f"expected {len(tasks)} tasks, got {len(rows)}")
    ids = []
    cranes, spots, corridor = {}, {}, []
    completions = []

    for row in rows:
        try:
            tid = int(row["task_id"])
        except ValueError:
            errors.append(f"bad task id {row.get('task_id')!r}")
            continue
        ids.append(tid)
        task = tasks.get(tid)
        if task is None:
            errors.append(f"unknown task {tid}")
            continue
        crane = as_int(row["crane"], f"task{tid}.crane", errors)
        spot = as_int(row["spot"], f"task{tid}.spot", errors)
        start = as_int(row["crane_start"], f"task{tid}.crane_start", errors)
        end = as_int(row["crane_end"], f"task{tid}.crane_end", errors)
        arrive = as_int(row["buffer_arrival"], f"task{tid}.buffer_arrival", errors)
        leave = as_int(row["buffer_departure"], f"task{tid}.buffer_departure", errors)
        drive = as_int(row["drive_entry"], f"task{tid}.drive_entry", errors)
        complete = as_int(row["completion"], f"task{tid}.completion", errors)
        wait = as_int(row["wait"], f"task{tid}.wait", errors)
        transport = as_int(row["transport_time"], f"task{tid}.transport_time", errors)
        c0 = as_int(row["corridor_start"], f"task{tid}.corridor_start", errors)
        c1 = as_int(row["corridor_end"], f"task{tid}.corridor_end", errors)
        if None in (crane, spot, start, end, arrive, leave, drive, complete,
                    wait, transport, c0, c1):
            continue

        expected_type = "load" if task["kind"] == "L" else "unload"
        if row["job_type"] != expected_type:
            errors.append(f"task{tid}: type {row['job_type']} != {expected_type}")
        if end - start != task["p"]:
            errors.append(f"task{tid}: crane duration {end - start} != {task['p']}")
        if wait != 0 or leave != arrive:
            errors.append(f"task{tid}: expected zero buffer wait")
        if leave - arrive != wait:
            errors.append(f"task{tid}: wait field inconsistent")

        if task["kind"] == "L":
            expected = travel_load.get((spot, crane))
            if expected is None:
                errors.append(f"task{tid}: no load travel entry for spot {spot}/crane {crane}")
                continue
            if drive < task["ready"]:
                errors.append(f"task{tid}: enters road at {drive} before release {task['ready']}")
            if arrive != drive + alpha:
                errors.append(f"task{tid}: alpha leg")
            if start != leave + expected:
                errors.append(f"task{tid}: buffer->crane leg")
            if complete != end:
                errors.append(f"task{tid}: completion should equal crane end")
            if c0 != drive or c1 != arrive:
                errors.append(f"task{tid}: corridor interval")
        else:
            expected = travel_unload.get((crane, spot))
            if expected is None:
                errors.append(f"task{tid}: no unload travel entry for crane {crane}/spot {spot}")
                continue
            if start < task["ready"]:
                errors.append(f"task{tid}: starts at {start} before release {task['ready']}")
            if arrive != end + expected:
                errors.append(f"task{tid}: crane->buffer leg")
            if complete != leave + beta:
                errors.append(f"task{tid}: beta leg")
            if drive != complete:
                errors.append(f"task{tid}: drive entry should equal completion")
            if c0 != arrive or c1 != complete:
                errors.append(f"task{tid}: corridor interval")
        if transport != expected:
            errors.append(f"task{tid}: transport field {transport} != {expected}")

        completions.append(complete)
        cranes.setdefault(crane, []).append((start, end, tid))
        if leave > arrive:
            spots.setdefault(spot, []).append((arrive, leave, tid))
        corridor.append((c0, c1))

    if sorted(ids) != sorted(tasks):
        errors.append("task ids do not match the data")
    if len(ids) != len(set(ids)):
        errors.append("duplicated task ids")

    for crane, intervals in cranes.items():
        intervals.sort()
        for a, b in zip(intervals, intervals[1:]):
            if a[1] > b[0]:
                errors.append(f"crane {crane}: overlap {a} / {b}")
    for spot, intervals in spots.items():
        intervals.sort()
        for a, b in zip(intervals, intervals[1:]):
            if a[1] > b[0]:
                errors.append(f"spot {spot}: overlap {a} / {b}")

    peak = 0
    if corridor:
        end = max(c1 for _, c1 in corridor) + 1
        count = [0] * (end + 2)
        for c0, c1 in corridor:
            for tau in range(max(c0, 0), c1):
                count[tau] += 1
        peak = max(count)
        if peak > capacity:
            errors.append(f"road capacity exceeded: {peak} > {capacity}")

    print(f"scenario: {args.scenario}")
    print(f"routes: {args.routes}")
    print(f"tasks: {len(ids)}  sum completion: {sum(completions)}  "
          f"makespan: {max(completions) if completions else '-'}")
    print(f"road peak: {peak}/{capacity}")
    if errors:
        print("\nFAIL")
        for message in errors:
            print(" -", message)
        sys.exit(1)
    print("\nPASS: all events rebuilt from data and all constraints satisfied")


if __name__ == "__main__":
    main()
