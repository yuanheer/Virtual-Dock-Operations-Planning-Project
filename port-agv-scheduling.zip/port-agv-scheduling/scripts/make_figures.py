#!/usr/bin/env python3
"""Generate the figures shown in the README and the report.

Run ``python scripts/experiments.py`` first; this script only reads the CSV
files in ``results/`` and the two bundled instances.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
import sys
sys.path.insert(0, str(ROOT))

from agvsched.exact import solve_dp
from agvsched.instance import load_instance

RESULTS = ROOT / "results"
FIG = RESULTS / "figures"
FIG.mkdir(parents=True, exist_ok=True)

BLUE = "#004F8A"
ORANGE = "#C97B3A"
GREEN = "#2F7D5B"
GREY = "#60758A"
LIGHT = "#EAF2F8"

plt.rcParams.update({
    "font.family": "DejaVu Sans",
    "font.size": 10,
    "axes.grid": True,
    "grid.alpha": 0.25,
    "axes.spines.top": False,
    "axes.spines.right": False,
    "figure.dpi": 150,
})


def read_csv(path: Path) -> list[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def fig_gantt(scenario: str) -> None:
    inst = load_instance(ROOT / "data", scenario)
    result = solve_dp(inst)
    plans = result["plans"]
    fig, (ax, ax2) = plt.subplots(2, 1, figsize=(9.2, 5.2),
                                  height_ratios=[1.2, 0.8], sharex=False)
    for y, crane in enumerate(inst.cranes):
        for p in sorted([p for p in plans if p.crane == crane], key=lambda q: q.start):
            ax.barh(y, p.end - p.start, left=p.start, height=0.5,
                    color=BLUE if y == 0 else "#4A86B8", edgecolor="white")
            ax.text((p.start + p.end) / 2, y, f"T{p.task_id}",
                    ha="center", va="center", color="white", fontsize=8, fontweight="bold")
    ax.set_yticks(range(inst.n_cranes), [f"crane-{k}" for k in inst.cranes])
    ax.invert_yaxis()
    ax.set_xlabel("time (instance units)")
    ax.set_title(f"{scenario}: optimal crane schedule (sum C = {result['objective']:.0f})")
    ax.grid(axis="x", alpha=0.3)

    end = max(p.corridor_end for p in plans) + 3
    count = np.zeros(end + 1, dtype=int)
    for p in plans:
        count[max(p.corridor_start, 0):p.corridor_end] += 1
    ax2.step(np.arange(end + 1), count, where="post", color=ORANGE, linewidth=1.5)
    ax2.fill_between(np.arange(end + 1), count, step="post", color=ORANGE, alpha=0.15)
    ax2.axhline(inst.road_capacity, color="#B03A2E", linestyle="--", linewidth=1,
                label=f"road capacity = {inst.road_capacity}")
    ax2.set_xlabel("time (instance units)")
    ax2.set_ylabel("vehicles on the road")
    ax2.set_ylim(0, inst.road_capacity + 1.5)
    ax2.legend(frameon=False, fontsize=8, loc="upper right")
    ax2.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    fig.savefig(FIG / f"gantt_{scenario}.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig_sensitivity() -> None:
    rows = read_csv(RESULTS / "sensitivity.csv")
    factors = ["cranes", "road_capacity", "travel_scale", "processing_scale",
               "ready_shift", "spots"]
    titles = {
        "cranes": "number of cranes",
        "road_capacity": "road capacity",
        "travel_scale": "travel time scale",
        "processing_scale": "processing time scale",
        "ready_shift": "release time shift",
        "spots": "number of buffer spots",
    }
    fig, axes = plt.subplots(2, 3, figsize=(12.5, 6.4))
    for ax, factor in zip(axes.ravel(), factors):
        for scenario, color, marker in (("load_only", BLUE, "o"), ("mixed", ORANGE, "s")):
            subset = [r for r in rows if r["factor"] == factor and r["scenario"] == scenario
                      and r.get("status") == "PROVEN_OPTIMAL"
                      and r["objective"] not in ("", "None")]
            xs = [float(r["value"]) for r in subset]
            ys = [float(r["objective"]) for r in subset]
            ax.plot(xs, ys, marker=marker, color=color, linewidth=1.6,
                    label=scenario if factor == factors[0] else None)
        ax.set_title(titles[factor], fontsize=10)
        ax.set_xlabel(factor.replace("_", " "))
        ax.set_ylabel("sum of completion times")
        ax.grid(alpha=0.25)
    fig.legend(frameon=False, loc="upper right", ncol=2)
    fig.suptitle("One-factor sensitivity (each point re-optimised)", y=1.01, fontsize=11)
    fig.tight_layout()
    fig.savefig(FIG / "sensitivity.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig_benchmark() -> None:
    path = RESULTS / "benchmark_heterogeneous_summary.csv"
    if not path.exists():
        return
    rows = read_csv(path)
    rows.sort(key=lambda r: float(r["mean_gap_pct"]))
    names = [r["method"].replace("rule_", "") for r in rows]
    means = [float(r["mean_gap_pct"]) for r in rows]
    fig, ax = plt.subplots(figsize=(7.6, 3.6))
    ax.barh(names, means, color=[BLUE if not n.startswith(("GA", "SA")) else ORANGE
                                 for n in names])
    ax.set_xlabel("mean gap to exact optimum (%)")
    ax.set_title("Heuristics on heterogeneous-processing instances")
    ax.invert_yaxis()
    ax.grid(axis="x", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIG / "benchmark_heuristics.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig_jit() -> None:
    rows = read_csv(RESULTS / "jit_check.csv")
    fig, ax = plt.subplots(figsize=(7.2, 3.6))
    for scenario, color, marker in (("load_only", BLUE, "o"), ("mixed", ORANGE, "s")):
        subset = [r for r in rows if r["scenario"] == scenario]
        xs = [float(r["travel_scale"]) for r in subset]
        ys = [float(r["margin"]) for r in subset]
        ax.plot(xs, ys, marker=marker, color=color, label=scenario, linewidth=1.6)
    ax.axhline(0, color="#B03A2E", linestyle="--", linewidth=1.1,
               label="sufficient condition boundary")
    ax.axvline(7 / 6, color=GREY, linestyle=":", linewidth=1.1,
               label="continuous threshold 7/6")
    ax.set_xlabel("travel time scale")
    ax.set_ylabel("margin p_min - spread - fixed leg")
    ax.set_title("When does the zero-wait reduction hold?")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "jit_margin.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def fig_dual() -> None:
    path = RESULTS / "dual_objective.csv"
    if not path.exists():
        return
    rows = read_csv(path)
    fig, ax = plt.subplots(figsize=(6.5, 3.4))
    labels = [r["scenario"] for r in rows]
    width = 0.35
    ax.bar(np.arange(len(rows)) - width / 2, [float(r["sumC_opt_sumC"]) for r in rows],
           width, color=BLUE, label="min sum C")
    ax.bar(np.arange(len(rows)) + width / 2,
           [float(r["best_sumC_under_Cmax"]) for r in rows],
           width, color=ORANGE, label="min sum C with Cmax <= Cmax*")
    ax.set_xticks(np.arange(len(rows)), labels)
    ax.set_ylabel("sum of completion times")
    ax.set_title("Adding the Cmax constraint does not cost sum C here")
    ax.legend(frameon=False, fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "dual_objective.png", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def main() -> None:
    for scenario in ("load_only", "mixed"):
        fig_gantt(scenario)
    fig_sensitivity()
    fig_benchmark()
    fig_jit()
    fig_dual()
    print("figures written to results/figures")


if __name__ == "__main__":
    main()
