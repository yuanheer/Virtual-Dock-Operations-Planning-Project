#!/usr/bin/env python3
"""Solve one instance and print a readable route table.

Examples
--------
    python scripts/solve.py --scenario load_only --method dp
    python scripts/solve.py --scenario mixed --method milp
    python scripts/solve.py --scenario mixed --method ga

The route CSV is written to ``results/routes_<scenario>_<method>.csv`` and can
be checked independently with ``python scripts/audit.py``.
"""

from __future__ import annotations

import argparse
import csv
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agvsched.exact import solve_dp, solve_milp          # noqa: E402
from agvsched.heuristics import (                         # noqa: E402
    dispatch_rules, genetic_algorithm, simulated_annealing,
)
from agvsched.instance import load_instance               # noqa: E402
from agvsched.model import jit_certificate                # noqa: E402

COLUMNS = ["task_id", "job_type", "crane", "spot", "route", "drive_entry",
           "buffer_arrival", "buffer_departure", "crane_start", "crane_end",
           "wait", "transport_time", "corridor_start", "corridor_end", "completion"]


def solve(inst, method: str) -> dict:
    if method == "dp":
        return solve_dp(inst)
    if method == "milp":
        return solve_milp(inst, time_limit=120)
    if method == "ga":
        return genetic_algorithm(inst, generations=120, seed=1)
    if method == "sa":
        return simulated_annealing(inst, restarts=4, seed=1)
    raise ValueError(method)


def print_plan(result: dict) -> None:
    plans = sorted(result["plans"], key=lambda p: (p.crane, p.start))
    m = result["metrics"]
    print(f"objective(sum C) = {m['sum_completion']}   makespan = {m['makespan']}   "
          f"mean C = {m['mean_completion']:.2f}")
    print(f"cranes: " + "  ".join(
        f"C{k}: {v['count']} tasks / busy {v['busy']}" for k, v in m["crane_load"].items()))
    print(f"road peak = {m['peak_corridor']} / {result.get('road_capacity', '')}"
          f"   max wait = {m['max_wait']}   total transport = {m['total_transport']}")
    print()
    print(f"{'crane':>5} {'seq':>3} {'task':>4} {'type':>6} {'spot':>4} "
          f"{'drive':>6} {'buffer':>6} {'start':>6} {'end':>5} {'done':>5}")
    for k in sorted({p.crane for p in plans}):
        for seq, p in enumerate([p for p in plans if p.crane == k], start=1):
            print(f"{k:>5} {seq:>3} {p.task_id:>4} "
                  f"{'load' if p.kind == 'L' else 'unload':>6} {p.spot:>4} "
                  f"{p.drive_entry:>6} {p.buffer_arrival:>6} {p.start:>6} "
                  f"{p.end:>5} {p.completion:>5}")
    print()


def write_csv(result: dict, path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as fh:
        writer = csv.DictWriter(fh, fieldnames=COLUMNS)
        writer.writeheader()
        for p in sorted(result["plans"], key=lambda q: q.task_id):
            row = p.as_row()
            writer.writerow({key: row[key] for key in COLUMNS})


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--scenario", choices=["load_only", "mixed"], default="load_only")
    parser.add_argument("--method", choices=["dp", "milp", "ga", "sa", "rules"], default="dp")
    args = parser.parse_args()

    inst = load_instance(ROOT / "data", args.scenario)
    cert = jit_certificate(inst)
    print(f"instance: {args.scenario}  tasks={inst.n}  cranes={inst.n_cranes}  "
          f"spots={inst.n_spots}  road_capacity={inst.road_capacity}")
    print(f"zero-wait condition: {cert['satisfied']}  "
          f"({cert['capacity_condition']}, travel spread={cert['travel_spread']})")
    print()

    if args.method == "rules":
        results = dispatch_rules(inst)
        results.sort(key=lambda r: r["objective"])
        print(f"{'rule':<12} {'sum C':>7} {'makespan':>9} {'gap vs best':>12}")
        best = results[0]["objective"]
        for r in results:
            print(f"{r['method']:<12} {r['metrics']['sum_completion']:>7} "
                  f"{r['metrics']['makespan']:>9} "
                  f"{(r['objective'] - best) / best * 100:>11.2f}%")
        print()
        result = results[0]
        result["method"] = "rules"
        result["road_capacity"] = inst.road_capacity
        write_csv(result, ROOT / "results" / f"routes_{args.scenario}_rules.csv")
        print_plan(result)
        return

    result = solve(inst, args.method)
    result["road_capacity"] = inst.road_capacity
    print(f"method={result['method']}  status={result['status']}  "
          f"gap={result.get('mip_gap')}  time={result['elapsed']:.2f}s")
    print()
    print_plan(result)
    out = ROOT / "results" / f"routes_{args.scenario}_{args.method}.csv"
    write_csv(result, out)
    print(f"route table written to {out.relative_to(ROOT)}")


if __name__ == "__main__":
    main()
