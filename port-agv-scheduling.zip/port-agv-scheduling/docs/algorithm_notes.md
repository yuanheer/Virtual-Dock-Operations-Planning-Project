# 算法笔记

这份笔记记录了代码里几个关键函数的来路，方便之后改参数或换算例时快速定位。完整推导见 [`project_report.md`](project_report.md)。

## 1. 解码器

输入：任务排列 `order`，可选的岸桥指派 `assign`。  
输出：每个任务的完整事件链。

```
crane_free[k] = 0
corridor[t] = 0
for pos, task in enumerate(order):
    candidates = [assign[pos]] if assign else [1..K]
    for k in candidates:
        start = max(task.release_k, crane_free[k])
        while corridor_interval(task, k, start) is full:
            start += 1
        key = (completion, start, k)
    pick k with smallest key
    plan = make_plan(task, k, start)
    update crane_free[k], corridor
```

复杂度：`O(n * K * H)`，其中 `H` 是时域长度；本算例 `H≈150`，一次解码不到 1 毫秒。解码器本身不会产生岸桥冲突，道路容量用数组检查。

为什么没有停车位容量检查：零等待归约后，任务在停车位的停留时间为 0；如果把停车位当成容量资源，会多出不必要的约束。

## 2. 二进制 DP

```
F(mask, f1, f2):
    if mask == 0: return 0
    best = +inf
    for j in mask:
        for k in {1,2}:
            start = max(f_k, earliest_start[j][k])
            c = start + p[j] + tail[j][k]
            nf = start + p[j]
            val = c + F(mask \ {j}, nf if k==1 else f1, f2 if k==1 else nf)
            best = min(best, val)
    return best
```

状态数上界 `2^n * H^2`，实际用字典缓存后只访问到可行状态。本算例 `n=10`，访问 11–18 万个状态。回溯时按同样的规则重建每个任务的 `(crane, start)`。

DP 不含道路容量；回溯后先跑 `verify`，通过才返回排程，否则只返回下界。这样即使零等待充分条件不成立，也不会把不可行解放进结果。

## 3. 时间索引 MILP

变量：对每个 `(task, spot, crane, start)` 生成一个 0-1 列。  
约束：

- 任务覆盖：每个任务恰好一列；
- 岸桥容量：同一岸桥同一时刻最多一列；
- 道路容量：同一时刻最多 Q 列；
- 列内的事件时刻由 `start` 和行驶时间直接算出来。

用 `scipy.optimize.milp`（HiGHS）求解，`mip_rel_gap=0`，时限 120 秒。两个算例都在 10 秒左右证明最优。

## 4. 启发式编码

所有启发式都搜索 `(order, assign)`：

- 交换：交换两个位置的任务和岸桥；
- 插入：把一个任务挪到另一个位置；
- 改派：只改某个任务的岸桥，不改顺序。

GA 用 OX 交叉保持排列合法，岸桥指派用均匀交叉；SA 用三种邻域，多起点降温。适应度就是解码后的 ΣC，因此不会出现“搜索出的解不可行”的情况。

## 5. 独立审计

`scripts/audit.py` 不导入 `agvsched`。它自己读 CSV，按装/卸两种事件链重算：

```
load:  drive + 13 == buffer_arrival
       buffer_arrival + tt == crane_start
       crane_end == completion
unload: crane_end + tt == buffer_arrival
        buffer_arrival + 13 == completion
```

然后检查岸桥区间、停车位区间和道路峰值。审计通过只能说明排程与数据一致，不说明它最优；最优性由 DP/MILP 的状态和 gap 给出。

## 6. 复现实验的注意点

- `solve.py`/`experiments.py` 会往 `results/` 写 CSV；重复运行会覆盖同名文件。
- 灵敏度里 `cranes=3/4` 是复制已有岸桥的行驶时间表做的 what-if，不是真实扩建。
- `road_capacity=1` 的混合场景在 120 秒内能证明最优（942），但 load_only 直接不可行。
- 如果换数据，先跑 `jit_certificate`；条件不成立时 DP 只当下界，不要直接把 `dp(relaxed)` 当答案。
