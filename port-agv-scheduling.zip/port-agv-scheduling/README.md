# 码头前沿 AGV 调度：从事件链到精确算法

一个小型的运筹学 / 排程算法项目：把集装箱码头前沿的 AGV 调度抽象成带释放时间、双岸桥和道路容量约束的调度问题，做了完整建模、精确求解、启发式对比和灵敏度分析。

> **第一次打开：** 双击 [`00_先看这里.html`](00_先看这里.html) 看总览和运行截图；想一键复现：双击 [`一键复现.bat`](一键复现.bat)。

我做的不是“调包跑一个模型”，而是把一个现场问题拆成可以证明的简化、写出两个互相独立的精确算法、再用一个不依赖求解器的审计脚本核对结果。仓库里的两个算例都可以在一分钟内复现。

![terminal solve](assets/screenshots/run_solve.png)

## 结果速览

| 算例 | 任务 | 岸桥 | 最优 ΣC | DP 解的 Cmax | DP 状态数 | DP 时间 | MILP 时间 | 下界 |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| 纯装船 `load_only` | 10 | 2 | **875** | 128 | 112,385 | 0.8 s | 9.5 s | 865 |
| 装/卸混合 `mixed` | 10 | 2 | **759** | 126 | 183,009 | 1.5 s | 8.4 s | 755 |

两个算例的零等待条件都成立（行驶时间极差 6，固定段 13，最短加工 20），所以归约后的模型就是原问题；DP 与 MILP 给出的目标值相同，路线又都通过独立审计。`mixed` 的最优解在 Cmax=105 时也能达到 ΣC=759，说明这两个目标在这组数据上并不冲突。

## 问题是什么

码头前沿的作业可以粗略看成：

- 装船：AGV 从行车区出发，经过缓冲区的一个停车位，到岸桥下方；岸桥把箱子装上船，任务完成。
- 卸船：岸桥把箱子放到 AGV 上，AGV 经过停车位，驶入行车区，任务完成。
- 行车区一次最多容纳 4 辆 AGV；停车位允许等待；岸桥一次只能服务一个任务。
- 每个任务有释放时间（最早能进入行车区/作业区）和岸桥加工时间。

目标是最小化所有任务的完成时间之和（ΣC）；另外也算了最小化最大完工时间（Cmax）做对比。

数据是一个 2 岸桥、4 停车位、10 个任务的小算例，数值做了抽象和脱敏，保留了现场问题的结构而不是真实码头数据。

## 建模上的两个关键点

### 1. 等待只可能发生在停车位

装载任务如果已经在停车位等，固定岸桥开工时刻后可以把进入行车区的时刻往后挪，等待清零而完成时间不变；卸载任务的停车等待清零只会让完成时刻更早。只要道路容量仍然够（下一节的充分条件），就能把任意可行解改造成每个任务零等待的解，ΣC 不会变大。于是问题从“带等待的连续时间调度”变成“每个任务只决定岸桥、停车位和岸桥开工时刻”。

### 2. 零等待之后，道路容量可以被一个充分条件吸收

零等待时，装船任务的 AGV 只在固定段 `[t-tt-13, t-tt]` 占用行车区，卸船任务只在 `[t+p+tt, t+p+tt+13]` 占用。对同一岸桥、同一方向，两个任务的道路区间不重叠的充分条件是

```
p_min - (max tt - min tt) >= 13
```

再加上 `Q >= d*K`（d 为方向数，K 为岸桥数），道路容量约束就自动满足。这个算例中 `20 - 6 = 14 >= 13`，`4 >= 2`，条件成立，因此后面的 DP 不需要显式处理道路容量。详细证明在 [`docs/project_report.md`](docs/project_report.md)。

## 算法

- **时间索引 MILP**：枚举 `(任务, 停车位, 岸桥, 开工时刻)` 四元组作为 0-1 变量，加任务覆盖、岸桥占用和道路容量约束，用 HiGHS 求解。它是“不依赖结构简化”的基准模型。
- **二进制 DP**（0.8–1.5 秒）：状态为 `(未调度任务集合, 岸桥1完工时刻, 岸桥2完工时刻)`，逐个任务做“左移”式安排。对 ΣC 目标，左移不会变差，所以 DP 在归约模型上是精确的。
- **解码器 + 启发式**：所有启发式共用同一个串行解码器（顺序 + 岸桥指派），再分别用 6 个派工规则、随机搜索、遗传算法和模拟退火搜索排列。
- **独立审计**：`scripts/audit.py` 不导入求解器，只读原始 CSV 和路线表，重建每个事件并检查岸桥互斥、道路容量、释放时间和完成事件。

## 快速开始

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt

# 求一个算例，打印路线表
python scripts/solve.py --scenario load_only --method dp
python scripts/solve.py --scenario mixed --method milp

# 独立核验
python scripts/audit.py --scenario load_only --routes results/routes_load_only_dp.csv

# 全部实验和图表（几分钟）
python scripts/experiments.py
python scripts/make_figures.py

# 单元测试
python -m unittest discover -s tests -v
```

不想装包也可以直接运行脚本，脚本会自己把仓库根目录加入 `sys.path`；核心包只依赖 `numpy`、`scipy` 和 `matplotlib`。

## 运行记录

下面四张图是命令的实际输出（截图时把本机路径简化成了 `C:\projects\port-agv-scheduling`）：

![solve](assets/screenshots/run_solve.png)

![experiments](assets/screenshots/run_experiments.png)

![tests](assets/screenshots/run_tests.png)

![audit](assets/screenshots/run_audit.png)

`audit.py` 不导入求解器，只读数据 CSV 和路线表；它和 `solve.py` 得到同一个 ΣC，才说明排程真的可行。

## 仓库结构

```
agvsched/
  instance.py    数据模型、行驶时间、释放时间、零等待证书
  model.py       事件链、串行解码器、指标、独立核验
  exact.py       时间索引 MILP、bitmask DP、SRPT 下界
  heuristics.py  派工规则、随机搜索、局部搜索、GA、SA
scripts/
  solve.py       求单个算例并导出路线表
  audit.py       不依赖求解器的路线审计
  experiments.py 精确解 / 启发式 / 灵敏度 / 零等待条件
  make_figures.py
data/            两个小算例的 CSV
results/         实验输出和图表
复现结果/        运行截图（中文命名）和预生成输出
docs/            建模与算法报告、项目总结
tests/           单元测试
```

## 实验

![gantt load](results/figures/gantt_load_only.png)

![gantt mixed](results/figures/gantt_mixed.png)

灵敏度分析覆盖岸桥数、行车区容量、行驶时间尺度、加工时间尺度、释放时间平移和停车位数量。每个点都重新求解，部分场景会退化成 MILP 求解，因此比基础算例慢。

![sensitivity](results/figures/sensitivity.png)

![jit margin](results/figures/jit_margin.png)

把加工时间改成 10–30 的随机值后，8 个扰动算例上 SA 的平均 gap 是 0.29%、GA 是 0.95%；最好的规则（ERD/MST）也有 5.75% 的平均差距，SA 的命中率 37.5%，GA 12.5%。数据在 `results/benchmark_heterogeneous_summary.csv`。

![benchmark](results/figures/benchmark_heuristics.png)

## 我踩过的坑

- 一开始想用“任务配对 + 大 M”的聚合模型，变量少，但 LP 松弛很弱，10 个任务就要跑很久，最后放弃，改成时间索引模型做基准。
- 贪心“能拼就拼”在这组数据上恰好等于最优，但我写了一个 4 任务的反例，贪心比精确解差 3.2，所以没把贪心当成通用算法。
- 零等待条件看起来太强，实际用起来刚好够：γ=1.1667 时取整后极差变成 8，条件不成立；γ=1.2 取整后极差回到 7，又成立了。这个非单调是整数取整造成的，写报告时特意保留了这组数据。
- DP 的返回值如果过不了道路容量检查，我只把它当下界，不返回排程。这个“宁可少给结果”的约束在调试时帮我抓到了两次事件链的符号错误。

## 限制

- 只有 10 个任务、2 台岸桥，规模远小于真实码头；没有做列生成或 CP-SAT 扩展。
- 目标只含任务完成时间，没有考虑岸桥作业计划、AGV 电量、充电、拥堵的随机性、司机班次等。
- 数据是抽象算例，不能用来推断某个真实码头的产能。
- 零等待归约依赖参数条件；换一组数据要先跑 `jit_certificate`，条件不成立时只能用 MILP，或者把 DP 当作下界。

## 文档

- [建模、算法与实验报告](docs/project_report.md)
- [一页总结](docs/summary.md)
- [算法笔记（伪代码与复杂度）](docs/algorithm_notes.md)

## 上传到 GitHub

仓库目前是一个普通目录，没有绑定远程。第一次上传可以这样做：

```bash
git init
git add .
git commit -m "port AGV scheduling: model, exact solvers and experiments"
git branch -M main
git remote add origin git@github.com:<your-account>/port-agv-scheduling.git
git push -u origin main
```

## License

MIT。见 [LICENSE](LICENSE)。
