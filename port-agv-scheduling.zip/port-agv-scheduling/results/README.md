# 计算结果

这些文件由 `scripts/experiments.py` 生成，`results/figures/` 由 `scripts/make_figures.py` 生成。

| Path | Content |
| --- | --- |
| `exact_summary.csv` | 两个算例的 DP / MILP 最优值、状态、求解时间、下界 |
| `heuristics_summary.csv` | 6 个派工规则 + 随机搜索 + GA + SA 的结果 |
| `benchmark_heterogeneous_*.csv` | 加工时间异构的 8 个扰动算例上的算法对比 |
| `sensitivity.csv` | 岸桥数、行车区容量、行驶时间、加工时间、释放时间、停车位数的一因素灵敏度 |
| `jit_check.csv` | 不同行驶时间尺度下零等待条件的余量 |
| `dual_objective.csv` | ΣC 与 Cmax 两个目标的关系 |
| `figures/*.png` | README 和报告里用的图 |

`routes_*.csv` 是 `scripts/solve.py` 输出的具体路线表，可以用 `scripts/audit.py` 独立核验。
