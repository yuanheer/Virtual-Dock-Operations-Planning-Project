本文件夹是给“直接发送、不需要额外解释”准备的运行证据。

内容：
  01_求解.png       运行 scripts/solve.py 的终端输出（DP，875）
  02_实验.png       运行 scripts/experiments.py 的终端输出
  03_测试.png       运行 10 个单元测试的输出
  04_独立核验.png   运行 scripts/audit.py 的独立核验输出
  复现输出.txt      一次完整复现的文本输出（预生成）

这些图也嵌在根目录的 00_先看这里.html 里，双击即可看到。
重新复现：双击根目录的 一键复现.bat，完整输出会写到 reproduction_output.txt。

说明：截图来自实际命令输出；截图中的路径做了简化（C:\projects\...），
不影响复现。
