"""Exact methods: time-indexed MILP, bitmask DP and a preemptive lower bound.

The instances in this repository are small (10 tasks), but I still implemented
two independent exact methods.  The MILP is the "obvious" formulation; the DP
is a much faster alternative for two cranes and is useful for checking that the
MILP result is not an artefact of the model.  They both solve the zero-wait
reduction, whose validity is checked by :func:`agvsched.model.jit_certificate`.
"""

from __future__ import annotations

import math
import time
from functools import lru_cache
from typing import Dict, List, Optional, Sequence, Tuple

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp
from scipy.sparse import coo_matrix

from .instance import Instance
from .model import Plan, make_plan, metrics, verify


def _options(inst: Instance, horizon: int) -> List[dict]:
    """Enumerate every feasible (task, spot, crane, crane start) column."""
    options = []
    for task in inst.tasks:
        for spot in inst.spots:
            for crane in inst.cranes:
                tt = inst.travel(task, crane, spot)
                earliest = task.ready + inst.alpha + tt if task.kind == "L" else task.ready
                for start in range(earliest, horizon - task.p + 1):
                    if task.kind == "L":
                        buffer_arrival = start - tt
                        drive_entry = buffer_arrival - inst.alpha
                        c0, c1 = buffer_arrival - inst.alpha, buffer_arrival
                        completion = start + task.p
                    else:
                        buffer_arrival = start + task.p + tt
                        completion = buffer_arrival + inst.beta
                        drive_entry = completion
                        c0, c1 = buffer_arrival, completion
                    if completion > horizon:
                        continue
                    options.append({
                        "task": task.task_id, "kind": task.kind, "spot": spot,
                        "crane": crane, "start": start, "end": start + task.p,
                        "buffer": buffer_arrival, "completion": completion,
                        "drive_entry": drive_entry, "transport": tt,
                        "c0": c0, "c1": c1,
                    })
    return options


def _build(inst: Instance, horizon: int, objective: str):
    options = _options(inst, horizon)
    n = len(options)
    task_pos = {t.task_id: i for i, t in enumerate(inst.tasks)}
    n_tasks = inst.n
    n_cranes = inst.n_cranes
    crane_off = n_tasks
    road_off = crane_off + n_cranes * horizon
    base_rows = road_off + horizon

    rows, cols, data = [], [], []
    for j, o in enumerate(options):
        rows.append(task_pos[o["task"]]); cols.append(j); data.append(1.0)
        base = crane_off + (o["crane"] - 1) * horizon
        for tau in range(o["start"], o["end"]):
            rows.append(base + tau); cols.append(j); data.append(1.0)
        for tau in range(max(o["c0"], 0), o["c1"]):
            rows.append(road_off + tau); cols.append(j); data.append(1.0)

    extra = n_tasks if objective == "makespan" else 0
    ncol = n + (1 if objective == "makespan" else 0)
    A = coo_matrix((np.array(data, dtype=float), (np.array(rows), np.array(cols))),
                   shape=(base_rows + extra, ncol)).tocsr()
    lower = np.zeros(base_rows + extra)
    upper = np.ones(base_rows + extra)
    lower[:n_tasks] = 1.0
    upper[road_off:base_rows] = inst.road_capacity

    if objective == "sum_completion":
        cost = np.array([o["completion"] for o in options], dtype=float)
        integrality = np.ones(n)
        var_lb = np.zeros(n)
        var_ub = np.ones(n)
    elif objective == "makespan":
        z = n
        rows2, cols2, data2 = [], [], []
        for j, o in enumerate(options):
            rows2.append(base_rows + task_pos[o["task"]]); cols2.append(j)
            data2.append(float(o["completion"]))
        for task in inst.tasks:
            rows2.append(base_rows + task_pos[task.task_id]); cols2.append(z)
            data2.append(-1.0)
        A = coo_matrix((np.array(data + data2, dtype=float),
                        (np.array(rows + rows2), np.array(cols + cols2))),
                       shape=(base_rows + extra, ncol)).tocsr()
        lower = np.concatenate([lower[:base_rows], np.full(n_tasks, -np.inf)])
        upper = np.concatenate([upper[:base_rows], np.zeros(n_tasks)])
        cost = np.zeros(ncol); cost[-1] = 1.0
        integrality = np.concatenate([np.ones(n), [0]])
        var_lb = np.zeros(ncol)
        var_ub = np.concatenate([np.ones(n), [horizon]])
    else:
        raise ValueError(objective)
    return options, A, lower, upper, cost, integrality, var_lb, var_ub, ncol


def solve_milp(inst: Instance, objective: str = "sum_completion",
               time_limit: float = 120.0,
               horizon: Optional[int] = None) -> dict:
    """Solve the time-indexed 0-1 model with HiGHS through scipy."""
    horizon = horizon or inst.horizon()
    options, A, lower, upper, cost, integrality, var_lb, var_ub, ncol = \
        _build(inst, horizon, objective)
    t0 = time.perf_counter()
    result = milp(
        cost, integrality=integrality,
        bounds=Bounds(var_lb, var_ub),
        constraints=LinearConstraint(A, lower, upper),
        options={"time_limit": time_limit, "mip_rel_gap": 0.0, "presolve": True},
    )
    elapsed = time.perf_counter() - t0
    if result.x is None:
        return {"method": "milp", "status": "INFEASIBLE", "objective": None,
                "plans": [], "elapsed": elapsed, "horizon": horizon,
                "n_vars": ncol, "n_cons": int(A.shape[0])}

    chosen = [options[j] for j, value in enumerate(result.x[:len(options)]) if value > 0.5]
    plans = []
    for o in chosen:
        task = inst.task_by_id[o["task"]]
        plans.append(Plan(
            task_id=o["task"], kind=o["kind"], ready=task.ready,
            crane=o["crane"], spot=o["spot"], transport=o["transport"],
            start=o["start"], end=o["end"], drive_entry=o["drive_entry"],
            buffer_arrival=o["buffer"], buffer_departure=o["buffer"],
            completion=o["completion"], corridor_start=o["c0"],
            corridor_end=o["c1"], wait=0,
        ))
    plans.sort(key=lambda p: p.task_id)
    verify(inst, plans)
    objective_value = (sum(p.completion for p in plans) if objective == "sum_completion"
                       else max(p.completion for p in plans))
    proven = result.status == 0 and getattr(result, "mip_gap", 1.0) < 1e-7
    return {
        "method": "milp", "objective_name": objective,
        "objective": float(objective_value), "plans": plans,
        "status": "PROVEN_OPTIMAL" if proven else "FEASIBLE_NOT_PROVEN",
        "lower_bound": float(result.mip_dual_bound) if result.mip_dual_bound is not None else None,
        "mip_gap": float(getattr(result, "mip_gap", float("nan"))),
        "elapsed": elapsed, "n_vars": ncol, "n_cons": int(A.shape[0]),
        "horizon": horizon, "metrics": metrics(inst, plans),
    }


def solve_dp(inst: Instance, cmax_cap: Optional[int] = None) -> dict:
    """Bitmask DP for two cranes: state (unscheduled mask, finish time on crane 1/2).

    The recursion schedules one task at a time at the earliest possible start
    on either crane.  For the sum-of-completion objective, left-shifting a task
    never hurts, so this covers the reduction exactly.  The road capacity is
    not part of the DP; the returned plan is certified only if it passes
    :func:`verify` (which is guaranteed when the zero-wait certificate holds).

    ``cmax_cap`` optionally rejects any task that would finish after the cap.
    This turns the DP into a lexicographic solver: first minimise Cmax, then
    minimise sum C subject to Cmax <= cap.
    """
    if inst.n > 14:
        raise ValueError("DP is intended for <= 14 tasks")
    if inst.n_cranes != 2:
        raise ValueError("DP implementation assumes two cranes")

    tasks = inst.tasks
    n = len(tasks)
    release = [[inst.earliest_start(t, k + 1) for k in range(2)] for t in tasks]
    tail = [[inst.tail(t, k + 1) for k in range(2)] for t in tasks]
    p = [t.p for t in tasks]
    full = (1 << n) - 1
    states = [0]

    @lru_cache(maxsize=None)
    def best(mask: int, f1: int, f2: int) -> Tuple[float, Optional[Tuple[int, int]]]:
        states[0] += 1
        if mask == 0:
            return 0.0, None
        value = math.inf
        move = None
        rest_mask = mask
        while rest_mask:
            low = rest_mask & -rest_mask
            j = low.bit_length() - 1
            rest_mask ^= low
            rest = mask ^ low
            for k in range(2):
                finish = f1 if k == 0 else f2
                start = max(finish, release[j][k])
                c = start + p[j] + tail[j][k]
                if cmax_cap is not None and c > cmax_cap:
                    continue
                nf = start + p[j]
                candidate = c + best(rest, nf if k == 0 else f1,
                                     f2 if k == 0 else nf)[0]
                if candidate < value:
                    value, move = candidate, (j, k)
        return value, move

    t0 = time.perf_counter()
    objective, _ = best(full, 0, 0)
    elapsed = time.perf_counter() - t0
    if math.isinf(objective):
        return {"method": "dp", "objective": None, "plans": [],
                "status": "INFEASIBLE", "lower_bound": None, "elapsed": elapsed,
                "states": states[0],
                "note": f"no plan satisfies the cap {cmax_cap}"}

    plans: List[Plan] = []
    mask, f1, f2 = full, 0, 0
    while mask:
        _, (j, k) = best(mask, f1, f2)
        finish = f1 if k == 0 else f2
        start = max(finish, release[j][k])
        plans.append(make_plan(inst, tasks[j], k + 1, start))
        nf = start + p[j]
        if k == 0:
            f1 = nf
        else:
            f2 = nf
        mask ^= (1 << j)
    plans.sort(key=lambda q: q.task_id)
    if cmax_cap is not None and max(p.completion for p in plans) > cmax_cap:
        raise AssertionError("cap violated")

    try:
        verify(inst, plans)
        certified = True
    except AssertionError:
        certified = False
    if certified:
        return {"method": "dp", "objective": float(objective), "plans": plans,
                "status": "PROVEN_OPTIMAL", "lower_bound": float(objective),
                "mip_gap": 0.0, "elapsed": elapsed, "states": states[0],
                "metrics": metrics(inst, plans)}
    return {"method": "dp(relaxed)", "objective": float(objective), "plans": [],
            "status": "RELAXED_LOWER_BOUND", "lower_bound": float(objective),
            "elapsed": elapsed, "states": states[0],
            "note": "plan fails the road-capacity check; only the bound is returned"}


def srpt_lower_bound(inst: Instance) -> dict:
    """Preemptive SRPT relaxation: jobs may migrate between cranes and be interrupted."""
    jobs = []
    for t in inst.tasks:
        release = min(inst.earliest_start(t, k + 1) for k in range(inst.n_cranes))
        tail = min(inst.tail(t, k + 1) for k in range(inst.n_cranes))
        jobs.append({"id": t.task_id, "release": release, "left": t.p,
                     "tail": tail, "done": None})
    remaining = list(jobs)
    now = min(j["release"] for j in remaining)
    total = 0.0
    while remaining:
        available = [j for j in remaining if j["release"] <= now]
        if not available:
            now = min(j["release"] for j in remaining)
            continue
        available.sort(key=lambda j: (j["left"], j["release"], j["id"]))
        for job in available[:inst.n_cranes]:
            job["left"] -= 1
            if job["left"] == 0:
                job["done"] = now + 1
                total += job["done"] + job["tail"]
        remaining = [j for j in remaining if j["done"] is None]
        now += 1
    return {"lb": total, "method": "preemptive_srpt"}


def dp_min_cmax(inst: Instance) -> int:
    """Smallest feasible makespan, found by binary search on the capped DP."""
    low, high = 0, inst.horizon()
    while low < high:
        mid = (low + high) // 2
        result = solve_dp(inst, cmax_cap=mid)
        if result["status"] == "PROVEN_OPTIMAL":
            high = mid
        else:
            low = mid + 1
    return low
