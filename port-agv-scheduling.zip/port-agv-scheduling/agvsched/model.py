"""Event-chain construction, schedule decoding and validation.

All algorithms in this repository share the same representation: a task order
plus a crane assignment.  A serial schedule generator turns that representation
into a feasible timetable.  Keeping the decoder in one place makes it much
easier to compare heuristics and exact methods on equal footing.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from .instance import Instance, Task


@dataclass
class Plan:
    task_id: int
    kind: str
    ready: int
    crane: int
    spot: int
    transport: int
    start: int
    end: int
    drive_entry: int
    buffer_arrival: int
    buffer_departure: int
    completion: int
    corridor_start: int
    corridor_end: int
    wait: int = 0

    @property
    def route(self) -> str:
        if self.kind == "L":
            return f"drive -> spot-{self.spot} -> crane-{self.crane}"
        return f"crane-{self.crane} -> spot-{self.spot} -> drive"

    def as_row(self) -> dict:
        return {
            "task_id": self.task_id,
            "job_type": "load" if self.kind == "L" else "unload",
            "ready_time": self.ready,
            "crane": self.crane,
            "spot": self.spot,
            "route": self.route,
            "drive_entry": self.drive_entry,
            "buffer_arrival": self.buffer_arrival,
            "buffer_departure": self.buffer_departure,
            "crane_start": self.start,
            "crane_end": self.end,
            "wait": self.wait,
            "transport_time": self.transport,
            "corridor_start": self.corridor_start,
            "corridor_end": self.corridor_end,
            "completion": self.completion,
        }


def make_plan(inst: Instance, task: Task, crane: int, start: int) -> Plan:
    """Build the full timetable of one task from its crane start time."""
    spot, tt = inst.fastest_spot(task, crane)
    end = start + task.p
    if task.kind == "L":
        buffer_arrival = start - tt
        drive_entry = buffer_arrival - inst.alpha
        completion = end
        corridor_start, corridor_end = drive_entry, buffer_arrival
    else:
        buffer_arrival = end + tt
        drive_entry = buffer_arrival + inst.beta
        completion = drive_entry
        corridor_start, corridor_end = buffer_arrival, drive_entry
    return Plan(
        task_id=task.task_id, kind=task.kind, ready=task.ready,
        crane=crane, spot=spot, transport=tt,
        start=start, end=end, drive_entry=drive_entry,
        buffer_arrival=buffer_arrival, buffer_departure=buffer_arrival,
        completion=completion, corridor_start=corridor_start,
        corridor_end=corridor_end, wait=0,
    )


def decode(inst: Instance, order: Sequence[int],
           crane_of: Optional[Sequence[int]] = None,
           rule: str = "earliest_completion") -> List[Plan]:
    """Serial schedule generation.

    The decoder walks through ``order``, chooses a crane (or follows the given
    assignment) and places the task at the earliest start time that respects
    the crane and the road capacity.  Under zero buffer waiting the parking
    spot is never occupied, so no spot-capacity check is needed here.
    """
    tasks = inst.task_by_id
    n_cranes = inst.n_cranes
    alpha, beta = inst.alpha, inst.beta
    cap = inst.road_capacity

    start_tab: Dict[Tuple[int, int], int] = {}
    travel_tab: Dict[Tuple[int, int], int] = {}
    for tid in order:
        task = tasks[tid]
        for k in inst.cranes:
            _, tt = inst.fastest_spot(task, k)
            travel_tab[(tid, k)] = tt
            start_tab[(tid, k)] = task.ready + alpha + tt if task.kind == "L" else task.ready

    crane_free = [0] * (n_cranes + 1)
    corridor = [0] * (inst.horizon() + 64)
    plans: List[Plan] = []

    for pos, tid in enumerate(order):
        task = tasks[tid]
        candidates = (crane_of[pos],) if crane_of is not None else inst.cranes
        best_key, best_k, best_t = None, 0, 0
        for k in candidates:
            tt = travel_tab[(tid, k)]
            t = max(start_tab[(tid, k)], crane_free[k])
            while True:
                if task.kind == "L":
                    c0, c1 = t - tt - alpha, t - tt
                else:
                    c0 = t + task.p + tt
                    c1 = c0 + beta
                fits = True
                for tau in range(max(c0, 0), c1):
                    if tau >= len(corridor):
                        corridor.extend([0] * (tau - len(corridor) + 2))
                    if corridor[tau] >= cap:
                        fits = False
                        break
                if fits:
                    break
                t += 1
            completion = t + task.p + (0 if task.kind == "L" else tt + beta)
            key = (completion, crane_free[k] if rule == "load_balance" else 0, t, k)
            if best_key is None or key < best_key:
                best_key, best_k, best_t = key, k, t

        plan = make_plan(inst, task, best_k, best_t)
        plans.append(plan)
        crane_free[best_k] = plan.end
        for tau in range(max(plan.corridor_start, 0), plan.corridor_end):
            if tau >= len(corridor):
                corridor.extend([0] * (tau - len(corridor) + 2))
            corridor[tau] += 1
    return plans


def metrics(inst: Instance, plans: Sequence[Plan]) -> dict:
    """Objective values and a few diagnostics used in the reports."""
    sum_completion = sum(p.completion for p in plans)
    makespan = max((p.completion for p in plans), default=0)
    end = max((p.corridor_end for p in plans), default=0)
    count = [0] * (end + 2)
    for p in plans:
        for tau in range(max(p.corridor_start, 0), p.corridor_end):
            count[tau] += 1
    peak = max(count) if count else 0
    crane_load = {}
    for k in inst.cranes:
        seq = sorted((p for p in plans if p.crane == k), key=lambda p: p.start)
        crane_load[k] = {
            "count": len(seq),
            "busy": sum(p.end - p.start for p in seq),
            "finish": max((p.end for p in seq), default=0),
        }
    return {
        "sum_completion": int(sum_completion),
        "makespan": int(makespan),
        "mean_completion": round(sum_completion / len(plans), 4) if plans else 0.0,
        "total_transport": int(sum(p.transport for p in plans)),
        "peak_corridor": int(peak),
        "max_wait": int(max((p.wait for p in plans), default=0)),
        "crane_load": crane_load,
    }


def verify(inst: Instance, plans: Sequence[Plan]) -> dict:
    """Rebuild every event from the task data and raise on the first violation.

    This is deliberately independent of the decoder: it only uses the instance
    and the plan fields, so a bug in ``decode`` cannot hide here.
    """
    if sorted(p.task_id for p in plans) != sorted(t.task_id for t in inst.tasks):
        raise AssertionError("task set mismatch")

    for p in plans:
        task = inst.task_by_id[p.task_id]
        if p.kind != task.kind:
            raise AssertionError(f"task {p.task_id}: wrong type")
        if p.end - p.start != task.p:
            raise AssertionError(f"task {p.task_id}: crane duration")
        tt = inst.travel(task, p.crane, p.spot)
        if task.kind == "L":
            if p.drive_entry < task.ready:
                raise AssertionError(f"task {p.task_id}: released too early")
            if p.buffer_arrival != p.drive_entry + inst.alpha:
                raise AssertionError(f"task {p.task_id}: alpha leg")
            if p.start != p.buffer_arrival + tt:
                raise AssertionError(f"task {p.task_id}: buffer-crane leg")
            if p.completion != p.end:
                raise AssertionError(f"task {p.task_id}: completion event")
        else:
            if p.start < task.ready:
                raise AssertionError(f"task {p.task_id}: released too early")
            if p.buffer_arrival != p.end + tt:
                raise AssertionError(f"task {p.task_id}: crane-buffer leg")
            if p.completion != p.buffer_arrival + inst.beta:
                raise AssertionError(f"task {p.task_id}: beta leg")
            if p.completion != p.drive_entry:
                raise AssertionError(f"task {p.task_id}: completion event")
        if p.wait != 0 or p.buffer_arrival != p.buffer_departure:
            raise AssertionError(f"task {p.task_id}: zero-wait expected")

    for k in inst.cranes:
        seq = sorted((p.start, p.end) for p in plans if p.crane == k)
        for a, b in zip(seq, seq[1:]):
            if a[1] > b[0]:
                raise AssertionError(f"crane {k}: overlap {a} {b}")

    for spot in inst.spots:
        seq = sorted((p.buffer_arrival, p.buffer_departure) for p in plans
                     if p.spot == spot and p.buffer_departure > p.buffer_arrival)
        for a, b in zip(seq, seq[1:]):
            if a[1] > b[0]:
                raise AssertionError(f"spot {spot}: overlap")

    end = max((p.corridor_end for p in plans), default=0)
    count = [0] * (end + 2)
    for p in plans:
        for tau in range(max(p.corridor_start, 0), p.corridor_end):
            count[tau] += 1
    peak = max(count) if count else 0
    if peak > inst.road_capacity:
        raise AssertionError(f"road capacity {peak}>{inst.road_capacity}")

    m = metrics(inst, plans)
    return {
        "validation": "PASS",
        "tasks": len(plans),
        "sum_completion": m["sum_completion"],
        "makespan": m["makespan"],
        "peak_corridor": peak,
        "max_wait": m["max_wait"],
    }


def jit_certificate(inst: Instance, base_delta: Optional[int] = None) -> dict:
    """Check the sufficient condition for the zero-wait reduction.

    For each crane and each direction we compute the spread of the travel
    times.  If p_min - spread >= fixed leg length, two tasks of the same
    direction cannot overlap in the road corridor.  A crane can contribute at
    most one interval per active direction, so Q >= d*K is enough, with
    d = 1 for a load-only instance and d = 2 for a mixed one.
    """
    p_min = min(t.p for t in inst.tasks)
    rows = []
    spreads = []
    ok = True
    for k in inst.cranes:
        for kind, table, fixed in (
            ("L", [inst.travel_load[(b, k)] for b in inst.spots], inst.alpha),
            ("U", [inst.travel_unload[(k, b)] for b in inst.spots], inst.beta),
        ):
            spread = max(table) - min(table)
            spreads.append(spread)
            margin = p_min - spread - fixed
            rows.append({"crane": k, "direction": kind,
                         "travel_spread": spread, "margin": margin})
            ok = ok and margin >= 0
    directions = len({t.kind for t in inst.tasks})
    capacity_ok = inst.road_capacity >= directions * inst.n_cranes
    actual_delta = max(spreads) if spreads else 0
    base = base_delta if base_delta is not None else actual_delta
    gamma_star = (p_min - min(inst.alpha, inst.beta)) / base if base else math.inf
    return {
        "satisfied": bool(ok and capacity_ok),
        "rows": rows,
        "directions": directions,
        "capacity_condition": f"Q >= {directions}*K",
        "travel_spread": actual_delta,
        "base_spread": base,
        "gamma_star": round(gamma_star, 4),
    }
