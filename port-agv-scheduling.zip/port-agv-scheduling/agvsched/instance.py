"""Instance model for the quay-side AGV dispatch problem.

The terminal layout is intentionally small: a road segment (the "drive zone")
that can hold at most Q vehicles, a buffer with B parking spots, and K quay
cranes.  A task is either a load (drive zone -> buffer -> crane) or an unload
(crane -> buffer -> drive zone).  Only the task timings matter for the model;
geometric coordinates are already converted into the travel-time tables.

Data lives in ``data/`` and is read with the standard library so that the core
package has no dependency on pandas.
"""

from __future__ import annotations

import csv
import math
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, List, Tuple

KIND_LABEL = {"L": "load", "U": "unload"}


@dataclass(frozen=True)
class Task:
    task_id: int
    ready: int
    kind: str          # "L" or "U"
    p: int             # crane processing time


@dataclass
class Instance:
    scenario: str
    tasks: Tuple[Task, ...]
    travel_load: Dict[Tuple[int, int], int]    # (spot, crane) -> time
    travel_unload: Dict[Tuple[int, int], int]  # (crane, spot) -> time
    alpha: int = 13          # drive zone -> buffer, load tasks
    beta: int = 13           # buffer -> drive zone, unload tasks
    road_capacity: int = 4
    n_spots: int = 4
    n_cranes: int = 2
    _fastest_cache: Dict[Tuple[int, int], Tuple[int, int]] = field(default_factory=dict, repr=False)

    @property
    def n(self) -> int:
        return len(self.tasks)

    @property
    def cranes(self) -> Tuple[int, ...]:
        return tuple(range(1, self.n_cranes + 1))

    @property
    def spots(self) -> Tuple[int, ...]:
        return tuple(range(1, self.n_spots + 1))

    @property
    def task_by_id(self) -> Dict[int, Task]:
        return {t.task_id: t for t in self.tasks}

    def travel(self, task: Task, crane: int, spot: int) -> int:
        if task.kind == "L":
            return self.travel_load[(spot, crane)]
        return self.travel_unload[(crane, spot)]

    def fastest_spot(self, task: Task, crane: int) -> Tuple[int, int]:
        """Return (spot, travel_time) with the shortest buffer-crane leg.

        Under the zero-wait property a task only pays the buffer->crane leg, so
        picking the fastest spot is a weak dominance rule (ties: lowest spot id).
        """
        key = (task.task_id, crane)
        if key in self._fastest_cache:
            return self._fastest_cache[key]
        best_spot, best_time = 1, math.inf
        for spot in self.spots:
            tt = self.travel(task, crane, spot)
            if tt < best_time:
                best_spot, best_time = spot, tt
        self._fastest_cache[key] = (best_spot, int(best_time))
        return self._fastest_cache[key]

    def earliest_start(self, task: Task, crane: int) -> int:
        """Earliest crane start time if the task waits nowhere."""
        _, tt = self.fastest_spot(task, crane)
        return task.ready + self.alpha + tt if task.kind == "L" else task.ready

    def tail(self, task: Task, crane: int) -> int:
        """Time between crane end and task completion (0 for load, tt+beta for unload)."""
        if task.kind == "L":
            return 0
        _, tt = self.fastest_spot(task, crane)
        return tt + self.beta

    def completion(self, task: Task, crane: int, start: int) -> int:
        return start + task.p + self.tail(task, crane)

    def corridor_interval(self, task: Task, crane: int, start: int) -> Tuple[int, int]:
        """Conservative occupancy of the drive-zone corridor (length 13)."""
        _, tt = self.fastest_spot(task, crane)
        if task.kind == "L":
            buffer_arrival = start - tt
            return buffer_arrival - self.alpha, buffer_arrival
        buffer_arrival = start + task.p + tt
        return buffer_arrival, buffer_arrival + self.beta

    def horizon(self) -> int:
        """Loose upper bound used by the time-indexed MILP and by list sizing."""
        earliest = max(
            t.ready + (self.alpha + max(self.travel_load.values()) if t.kind == "L" else 0)
            for t in self.tasks
        )
        tail = max([0] + [max(self.travel_unload.values()) + self.beta
                          for t in self.tasks if t.kind == "U"])
        block = math.ceil(self.n / self.n_cranes) * max(t.p for t in self.tasks)
        return int(earliest + block + tail)

    def with_options(self, *, travel_scale: float = 1.0, p_scale: float = 1.0,
                     ready_shift: int = 0, n_cranes: int = None,
                     road_capacity: int = None, n_spots: int = None) -> "Instance":
        """Create a variant of this instance for sensitivity experiments.

        Scaling/rounding keeps everything integral, which matters because the
        MILP is time-indexed.  Negative ready times are allowed: shifting all
        release dates is equivalent to moving the time origin.
        """
        tasks = tuple(
            Task(t.task_id, int(round(t.ready + ready_shift)),
                 t.kind, int(round(t.p * p_scale)))
            for t in self.tasks
        )
        load = {k: max(1, int(round(v * travel_scale))) for k, v in self.travel_load.items()}
        unload = {k: max(1, int(round(v * travel_scale))) for k, v in self.travel_unload.items()}
        return Instance(
            scenario=self.scenario, tasks=tasks,
            travel_load=load, travel_unload=unload,
            alpha=self.alpha, beta=self.beta,
            road_capacity=road_capacity if road_capacity is not None else self.road_capacity,
            n_spots=n_spots if n_spots is not None else self.n_spots,
            n_cranes=n_cranes if n_cranes is not None else self.n_cranes,
        )


def _read_csv(path: Path) -> List[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        return list(csv.DictReader(fh))


def load_instance(data_dir: Path | str, scenario: str) -> Instance:
    """Load one of the two bundled scenarios.

    Parameters
    ----------
    data_dir : path to the ``data`` folder
    scenario : "load_only" or "mixed"
    """
    data_dir = Path(data_dir)
    task_file = {"load_only": "tasks_load_only.csv", "mixed": "tasks_mixed.csv"}[scenario]

    tasks = tuple(
        Task(int(r["task_id"]), int(r["ready_time"]),
             "L" if r["job_type"] == "load" else "U",
             int(r["processing_time"]))
        for r in _read_csv(data_dir / task_file)
    )
    load = {(int(r["spot"]), int(r["crane"])): int(r["travel_time"])
            for r in _read_csv(data_dir / "travel_loading.csv")}
    unload = {(int(r["crane"]), int(r["spot"])): int(r["travel_time"])
              for r in _read_csv(data_dir / "travel_unloading.csv")}
    fixed = {r["job_type"]: int(r["travel_time"])
             for r in _read_csv(data_dir / "fixed_travel.csv")}
    resources = {r["parameter"]: int(r["value"])
                 for r in _read_csv(data_dir / "resources.csv")}

    return Instance(
        scenario=scenario, tasks=tasks,
        travel_load=load, travel_unload=unload,
        alpha=fixed["load"], beta=fixed["unload"],
        road_capacity=resources["road_capacity"],
        n_spots=resources["spots"], n_cranes=resources["cranes"],
    )
