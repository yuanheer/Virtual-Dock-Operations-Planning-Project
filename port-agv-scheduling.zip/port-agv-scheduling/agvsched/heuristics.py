"""Heuristics and metaheuristics.

All methods encode a solution as ``order`` (task priority) plus ``assign``
(crane per position) and use :func:`agvsched.model.decode` as the common
feasibility-preserving decoder.  That keeps the comparison fair: the only
difference between algorithms is how they search the permutation space.
"""

from __future__ import annotations

import math
import random
import time
from typing import Dict, List, Optional, Sequence, Tuple

from .instance import Instance
from .model import Plan, decode, metrics, verify

RULES = {
    "FCFS": "first come first served (ready time)",
    "SPT": "shortest crane processing time",
    "ERD": "earliest possible crane start",
    "MST": "minimum slack time",
    "LPT": "longest crane processing time",
    "EDD": "earliest theoretical completion",
}


def evaluate(inst: Instance, order: Sequence[int],
             assign: Optional[Sequence[int]] = None,
             objective: str = "sum_completion") -> Tuple[float, List[Plan]]:
    plans = decode(inst, order, assign)
    if objective == "sum_completion":
        value = float(sum(p.completion for p in plans))
    elif objective == "makespan":
        value = float(max(p.completion for p in plans))
    else:
        raise ValueError(objective)
    return value, plans


def _pack(inst: Instance, method: str, order, assign, value, plans,
          elapsed: float, evaluations: int = 0, history=None) -> dict:
    verify(inst, plans)
    return {
        "method": method, "order": list(order),
        "assign": list(assign) if assign is not None else None,
        "objective": value, "plans": plans, "metrics": metrics(inst, plans),
        "elapsed": elapsed, "evaluations": evaluations,
        "history": history or [],
    }


def dispatch_rules(inst: Instance, objective: str = "sum_completion") -> List[dict]:
    """Evaluate the six simple priority rules used as baselines."""
    tasks = inst.tasks
    release_min = {t.task_id: min(inst.earliest_start(t, k) for k in inst.cranes) for t in tasks}
    release_max = {t.task_id: max(inst.earliest_start(t, k) for k in inst.cranes) for t in tasks}
    keys = {
        "FCFS": lambda t: (t.ready, t.task_id),
        "SPT": lambda t: (t.p, t.ready, t.task_id),
        "ERD": lambda t: (release_min[t.task_id], t.task_id),
        "MST": lambda t: (release_max[t.task_id] - release_min[t.task_id],
                          release_min[t.task_id], t.task_id),
        "LPT": lambda t: (-t.p, -t.ready, t.task_id),
        "EDD": lambda t: (inst.completion(t, 1, release_min[t.task_id]), t.task_id),
    }
    out = []
    for name, key in keys.items():
        order = [t.task_id for t in sorted(tasks, key=key)]
        t0 = time.perf_counter()
        value, plans = evaluate(inst, order, None, objective)
        out.append(_pack(inst, f"rule_{name}", order, None, value, plans,
                         time.perf_counter() - t0))
    return out


def random_search(inst: Instance, runs: int = 300, seed: int = 0,
                  objective: str = "sum_completion") -> dict:
    rng = random.Random(seed)
    ids = [t.task_id for t in inst.tasks]
    best = None
    t0 = time.perf_counter()
    for _ in range(runs):
        order = ids[:]
        rng.shuffle(order)
        value, plans = evaluate(inst, order, None, objective)
        if best is None or value < best[0]:
            best = (value, order, plans)
    value, order, plans = best
    return _pack(inst, "random_search", order, None, value, plans,
                 time.perf_counter() - t0, evaluations=runs)


def _greedy_assign(inst: Instance, order: Sequence[int]) -> List[int]:
    plans = decode(inst, order, None)
    by_id = {p.task_id: p.crane for p in plans}
    return [by_id[tid] for tid in order]


def local_search(inst: Instance, order: Sequence[int], assign: Sequence[int],
                 objective: str = "sum_completion", max_iter: int = 200) -> dict:
    """First-improvement local search with insertion and reassignment moves."""
    t0 = time.perf_counter()
    order, assign = list(order), list(assign)
    current, _ = evaluate(inst, order, assign, objective)
    evaluations = 1
    n = len(order)
    improved = True
    iteration = 0
    while improved and iteration < max_iter:
        improved = False
        iteration += 1
        for i in range(n):
            for j in range(n):
                if i == j:
                    continue
                cand_order = order[:]
                item = cand_order.pop(i)
                cand_order.insert(j, item)
                cand_assign = assign[:]
                item_assign = cand_assign.pop(i)
                cand_assign.insert(j, item_assign)
                value, _ = evaluate(inst, cand_order, cand_assign, objective)
                evaluations += 1
                if value < current - 1e-9:
                    order, assign, current = cand_order, cand_assign, value
                    improved = True
                    break
            if improved:
                break
        if improved:
            continue
        for i in range(n):
            for k in inst.cranes:
                if k == assign[i]:
                    continue
                cand_assign = assign[:]
                cand_assign[i] = k
                value, _ = evaluate(inst, order, cand_assign, objective)
                evaluations += 1
                if value < current - 1e-9:
                    assign, current = cand_assign, value
                    improved = True
                    break
            if improved:
                break
    return _pack(inst, "local_search", order, assign, current,
                 decode(inst, order, assign), time.perf_counter() - t0,
                 evaluations=evaluations)


def _ox(rng: random.Random, p1: List[int], p2: List[int]) -> List[int]:
    n = len(p1)
    a, b = sorted(rng.sample(range(n), 2))
    child = [None] * n
    child[a:b + 1] = p1[a:b + 1]
    fill = [x for x in p2 if x not in set(p1[a:b + 1])]
    cursor = 0
    for i in list(range(b + 1, n)) + list(range(0, a)):
        child[i] = fill[cursor]
        cursor += 1
    return child


def genetic_algorithm(inst: Instance, objective: str = "sum_completion",
                      pop_size: int = 60, generations: int = 150,
                      seed: int = 0) -> dict:
    """GA with permutation + crane-assignment encoding, OX crossover and elitism."""
    rng = random.Random(seed)
    ids = [t.task_id for t in inst.tasks]
    n = len(ids)

    def random_individual():
        order = ids[:]
        rng.shuffle(order)
        assign = [rng.choice(inst.cranes) for _ in range(n)]
        return order, assign

    population = [random_individual() for _ in range(pop_size)]
    scored = [(evaluate(inst, o, a, objective)[0], (o, a)) for o, a in population]
    evaluations = len(scored)
    best_value, best_ind = min(scored, key=lambda z: z[0])
    history = [best_value]

    def fitness(ind):
        return evaluate(inst, ind[0], ind[1], objective)[0]

    t0 = time.perf_counter()
    for _ in range(generations):
        scored.sort(key=lambda z: z[0])
        new_pop = [ind for _, ind in scored[:2]]
        while len(new_pop) < pop_size:
            parents = [rng.choice(scored) for _ in range(3)]
            p1 = min(parents, key=lambda z: z[0])[1]
            parents = [rng.choice(scored) for _ in range(3)]
            p2 = min(parents, key=lambda z: z[0])[1]
            if rng.random() < 0.9:
                order = _ox(rng, p1[0], p2[0])
                assign = [p1[1][i] if rng.random() < 0.5 else p2[1][i] for i in range(n)]
            else:
                order, assign = p1[0][:], p1[1][:]
            if rng.random() < 0.4:
                i, j = rng.sample(range(n), 2)
                order[i], order[j] = order[j], order[i]
                assign[i], assign[j] = assign[j], assign[i]
            if rng.random() < 0.3:
                i, j = rng.randrange(n), rng.randrange(n)
                order.insert(j, order.pop(i))
                assign.insert(j, assign.pop(i))
            if rng.random() < 0.2:
                assign[rng.randrange(n)] = rng.choice(inst.cranes)
            new_pop.append((order, assign))
        scored = [(fitness(ind), ind) for ind in new_pop]
        evaluations += len(scored)
        generation_best = min(scored, key=lambda z: z[0])
        if generation_best[0] < best_value:
            best_value, best_ind = generation_best
        history.append(best_value)
    order, assign = best_ind
    return _pack(inst, "genetic_algorithm", order, assign, best_value,
                 decode(inst, order, assign), time.perf_counter() - t0,
                 evaluations=evaluations, history=history)


def simulated_annealing(inst: Instance, objective: str = "sum_completion",
                        restarts: int = 5, iters_per_temp: int = 120,
                        t_start: float = 60.0, t_end: float = 0.5,
                        alpha: float = 0.93, seed: int = 0) -> dict:
    """Multi-start SA with swap, insertion and reassignment moves."""
    rng = random.Random(seed)
    ids = [t.task_id for t in inst.tasks]
    n = len(ids)
    t0 = time.perf_counter()
    evaluations = 0
    global_best = None
    history = []
    for _ in range(restarts):
        order = ids[:]
        rng.shuffle(order)
        assign = [rng.choice(inst.cranes) for _ in range(n)]
        current_value, _ = evaluate(inst, order, assign, objective)
        evaluations += 1
        best_order, best_assign, best_value = order[:], assign[:], current_value
        temperature = t_start
        while temperature > t_end:
            for _ in range(iters_per_temp):
                cand_order, cand_assign = order[:], assign[:]
                move = rng.random()
                if move < 0.45:
                    i, j = rng.sample(range(n), 2)
                    cand_order[i], cand_order[j] = cand_order[j], cand_order[i]
                    cand_assign[i], cand_assign[j] = cand_assign[j], cand_assign[i]
                elif move < 0.85:
                    i, j = rng.randrange(n), rng.randrange(n)
                    cand_order.insert(j, cand_order.pop(i))
                    cand_assign.insert(j, cand_assign.pop(i))
                else:
                    cand_assign[rng.randrange(n)] = rng.choice(inst.cranes)
                value, _ = evaluate(inst, cand_order, cand_assign, objective)
                evaluations += 1
                delta = value - current_value
                if delta <= 0 or rng.random() < math.exp(-delta / max(temperature, 1e-9)):
                    order, assign, current_value = cand_order, cand_assign, value
                    if current_value < best_value - 1e-9:
                        best_order = order[:]
                        best_assign = assign[:]
                        best_value = current_value
            history.append(best_value)
            temperature *= alpha
        if global_best is None or best_value < global_best[0]:
            global_best = (best_value, best_order, best_assign)
    value, order, assign = global_best
    return _pack(inst, "simulated_annealing", order, assign, value,
                 decode(inst, order, assign), time.perf_counter() - t0,
                 evaluations=evaluations, history=history)
