"""A small research project on quay-side AGV dispatch.

The package contains an instance loader, a shared schedule decoder, two exact
methods and a handful of heuristics used for comparison.
"""

__version__ = "0.1.0"
