@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"

echo ============================================================
echo  Port AGV scheduling - one-click reproduction
echo ============================================================
echo.

set "PY=python"
%PY% --version >nul 2>&1
if errorlevel 1 set "PY=py"
%PY% --version >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python not found. Install Python 3.10+ from python.org
    echo         and enable "Add python.exe to PATH".
    echo.
    pause
    exit /b 1
)

echo Using:
%PY% --version
echo.

%PY% -c "import numpy, scipy, matplotlib" >nul 2>&1
if errorlevel 1 (
    echo Installing dependencies ...
    %PY% -m pip install -r requirements.txt
    if errorlevel 1 (
        echo [ERROR] pip install failed. Check your network and try again.
        echo.
        pause
        exit /b 1
    )
    echo.
)

set "OUT=reproduction_output.txt"
echo Reproducing ... output goes to %OUT%
echo.

echo [1/4] solve load_only with DP
%PY% scripts\solve.py --scenario load_only --method dp > "%OUT%" 2>&1
echo       exit code: %errorlevel%

echo [2/4] independent audit
%PY% scripts\audit.py --scenario load_only --routes results\routes_load_only_dp.csv >> "%OUT%" 2>&1
echo       exit code: %errorlevel%

echo [3/4] unit tests
%PY% -m unittest discover -s tests -v >> "%OUT%" 2>&1
echo       exit code: %errorlevel%

echo [4/4] quick experiments
%PY% scripts\experiments.py --skip-slow >> "%OUT%" 2>&1
echo       exit code: %errorlevel%

echo.
echo ============================================================
echo  Done. Full output:
echo  %CD%\%OUT%
echo ============================================================
echo.

if not "%NO_PAUSE%"=="1" (
    echo Press any key to show the output ...
    pause >nul
    type "%OUT%"
    echo.
    echo Press any key to close.
    pause >nul
)
