"""Small unit tests for the core model and exact methods."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from agvsched.exact import dp_min_cmax, solve_dp, solve_milp, srpt_lower_bound
from agvsched.heuristics import dispatch_rules, genetic_algorithm
from agvsched.instance import load_instance
from agvsched.model import decode, jit_certificate, metrics, verify

DATA = ROOT / "data"


class TestInstance(unittest.TestCase):
    def test_shapes(self):
        for scenario in ("load_only", "mixed"):
            inst = load_instance(DATA, scenario)
            self.assertEqual(inst.n, 10)
            self.assertEqual(inst.n_cranes, 2)
            self.assertEqual(inst.n_spots, 4)
            self.assertEqual(inst.road_capacity, 4)

    def test_zero_wait_certificate(self):
        for scenario in ("load_only", "mixed"):
            inst = load_instance(DATA, scenario)
            cert = jit_certificate(inst)
            self.assertTrue(cert["satisfied"])
            self.assertEqual(cert["travel_spread"], 6)
            self.assertAlmostEqual(cert["gamma_star"], 7 / 6, places=3)

    def test_ready_time_shift_keeps_structure(self):
        inst = load_instance(DATA, "mixed")
        shifted = inst.with_options(ready_shift=-3)
        self.assertEqual(shifted.tasks[0].ready, inst.tasks[0].ready - 3)


class TestDecoder(unittest.TestCase):
    def test_dispatch_rules_are_feasible(self):
        inst = load_instance(DATA, "mixed")
        results = dispatch_rules(inst)
        self.assertEqual(len(results), 6)
        for result in results:
            verify(inst, result["plans"])
            self.assertGreater(result["metrics"]["sum_completion"], 0)

    def test_decode_ties_to_earliest_completion(self):
        inst = load_instance(DATA, "load_only")
        order = [t.task_id for t in inst.tasks]
        plans = decode(inst, order)
        self.assertEqual(len(plans), 10)
        verify(inst, plans)
        self.assertEqual(metrics(inst, plans)["max_wait"], 0)


class TestExact(unittest.TestCase):
    def test_dp_optima(self):
        expected = {"load_only": 875, "mixed": 759}
        for scenario, value in expected.items():
            inst = load_instance(DATA, scenario)
            result = solve_dp(inst)
            self.assertEqual(result["status"], "PROVEN_OPTIMAL")
            self.assertEqual(result["objective"], value)
            verify(inst, result["plans"])

    def test_milp_matches_dp(self):
        for scenario, value in {"load_only": 875, "mixed": 759}.items():
            inst = load_instance(DATA, scenario)
            result = solve_milp(inst, time_limit=60)
            self.assertEqual(result["objective"], value)
            self.assertEqual(result["status"], "PROVEN_OPTIMAL")

    def test_min_makespan_and_capped_dp(self):
        inst = load_instance(DATA, "mixed")
        self.assertEqual(dp_min_cmax(inst), 105)
        capped = solve_dp(inst, cmax_cap=105)
        self.assertEqual(capped["status"], "PROVEN_OPTIMAL")
        self.assertEqual(capped["objective"], 759)
        self.assertLessEqual(max(p.completion for p in capped["plans"]), 105)

    def test_srpt_bound_is_lower(self):
        for scenario, optimal in {"load_only": 875, "mixed": 759}.items():
            inst = load_instance(DATA, scenario)
            bound = srpt_lower_bound(inst)["lb"]
            self.assertLessEqual(bound, optimal)


class TestHeuristics(unittest.TestCase):
    def test_genetic_algorithm_reaches_optimum(self):
        inst = load_instance(DATA, "load_only")
        result = genetic_algorithm(inst, pop_size=30, generations=60, seed=3)
        self.assertEqual(result["objective"], 875)
        verify(inst, result["plans"])


if __name__ == "__main__":
    unittest.main()
